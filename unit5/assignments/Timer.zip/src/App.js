import { useState } from "react";
import Timer from "./Components/Timer";
import "./styles.css";

export default function App() {
  const [show, setShow] = useState(false);
  const [start, setStart] = useState(0);
  const [end, setEnd] = useState(30);
  const handleShow = () => {
    setShow(!show);
  };

  return (
    <div className="App">
      {!show && (
        <>
          <input
            type="number"
            placeholder="Start"
            onChange={(e) => setStart(e.target.value)}
          />
          <input
            type="number"
            placeholder="End"
            onChange={(e) => setEnd(e.target.value)}
          />
          <button onClick={handleShow}>Show</button>
        </>
      )}
      {show && (
        <Timer
          handleShow={handleShow}
          start={Number(start)}
          end={Number(end)}
        />
      )}
    </div>
  );
}
