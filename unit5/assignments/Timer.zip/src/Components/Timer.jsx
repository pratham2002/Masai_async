import { useEffect, useRef, useState } from "react";

function Timer({ handleShow, start, end }) {
  const timerId = useRef();
  const [time, setTimer] = useState(start);
  useEffect(() => {
    const id = setInterval(() => {
      setTimer((prev) => prev + 1);
    }, 1000);
    timerId.current.value = id;
    // console.log(timerId.current.value);

    return () => clearInterval(timerId);
  }, []);
  if (time === end) {
    clearInterval(timerId.current.value);
  }

  return (
    <>
      <button onClick={handleShow}>Hide</button>
      <h1>Timer</h1>
      <h2 ref={timerId}>{time}</h2>
      <h2>{end}</h2>
    </>
  );
}

export default Timer;
