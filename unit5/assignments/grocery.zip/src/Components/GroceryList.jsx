export default function GroceryList({ value, onDelete }) {
  console.log("value", value);

  return (
    <div
      style={{
        display: "flex",
        gap: "1rem",
        width: "30%",
        margin: "auto",
        alignItems: "center"
      }}
    >
      <h3>{value.title}</h3>
      <button onClick={() => onDelete(value)}>Delete</button>
    </div>
  );
}
