import { useState } from "react";
import GroceryInput from "./GroceryInput";
import GroceryList from "./GroceryList";

function Grocery() {
  const [todos, setTodos] = useState([]);
  const handleTaskCreate = (title) => {
    const payload = {
      title: title,
      id: todos.length + 1
    };
    setTodos([...todos, payload]);
  };
  const onDelete = (item) => {
    const newList = todos.filter((value) => value.id !== item.id);

    setTodos(newList);
  };

  return (
    <>
      <h2>List</h2>
      <GroceryInput onTaskCreate={handleTaskCreate} />
      {todos?.map((e) => {
        return <GroceryList onDelete={onDelete} value={e} key={e.id} />;
      })}
    </>
  );
}

export default Grocery;
