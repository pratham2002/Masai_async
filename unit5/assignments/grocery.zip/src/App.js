import Grocery from "./Components/Grocery";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <Grocery />
    </div>
  );
}
