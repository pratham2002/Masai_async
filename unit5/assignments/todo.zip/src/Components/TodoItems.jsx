export default function TodoDisplay({ todos }) {
  // console.log(todos);

  return (
    <div>
      {todos?.map((e) => {
        return (
          <>
            <h3 key={e.id}>
              Title:{e.title} - Status:{e.status ? "Complete" : "Incomplete"}
              <button key={e.id}>Toggle</button>
            </h3>
          </>
        );
      })}
    </div>
  );
}
