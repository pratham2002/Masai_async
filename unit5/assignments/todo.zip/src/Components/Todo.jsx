import { useState } from "react";
import TodoInput from "./TodoInput";
import TodoDisplay from "./TodoItems";

function Todo() {
  const [todos, setTodos] = useState([]);
  const handleTaskCreate = (title) => {
    const payload = {
      title: title,
      status: false,
      id: todos.length + 1
    };
    setTodos([...todos, payload]);
  };

  return (
    <>
      <h2>Todo</h2>
      <TodoInput onTaskCreate={handleTaskCreate} />
      <TodoDisplay todos={todos} />
    </>
  );
}

export default Todo;
